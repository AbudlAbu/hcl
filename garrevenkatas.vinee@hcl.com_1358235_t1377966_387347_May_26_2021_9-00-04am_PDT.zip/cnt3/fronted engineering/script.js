
const buttons = document.querySelectorAll('button');
const display = document.querySelector('.display');

buttons.forEach(function(button)
{
  button.addEventListener('click',calculate);
});

function calculate(event)
{
  const clickedbuttonvalue = event.target.value;
  if(clickedbuttonvalue === '=')
  {
    if(display.value != '')
    {
      display.value = eval(display.value);
    }
    if(display.value.length > 9)
    {
      display.value="range exceeded";
    }
  }
  else if(clickedbuttonvalue === 'C')
  {
    display.value='';
  }
  else
  {
    display.value += clickedbuttonvalue;
    if(display.value.length > 9)
    {
      display.value="range exceeded";
    }
  } 
}